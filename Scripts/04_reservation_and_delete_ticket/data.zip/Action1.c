Action1()
{

	/*Possible OAUTH authorization was detected. It is recommended to correlate the authorization parameters.*/

	lr_start_transaction("link");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_add_cookie("MSO=SID&1622367351; DOMAIN=192.168.176.1");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("welcome.pl", 
		"URL=http://192.168.176.1:1080/cgi-bin/welcome.pl?signOff=true", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://192.168.176.1:1080/WebTours/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("MSO=SID&1622367406; DOMAIN=192.168.176.1");

	lr_end_transaction("link",LR_AUTO);

	lr_start_transaction("login");

	web_add_header("Origin", 
		"http://192.168.176.1:1080");

	lr_think_time(8);

	web_submit_form("login.pl", 
		"Snapshot=t28.inf", 
		ITEMDATA, 
		"Name=username", "Value=jojo20", ENDITEM, 
		"Name=password", "Value=jojo", ENDITEM, 
		LAST);

	lr_end_transaction("login",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("flights");

	web_image("Search Flights Button", 
		"Alt=Search Flights Button", 
		"Snapshot=t29.inf", 
		LAST);

	return 0;
}